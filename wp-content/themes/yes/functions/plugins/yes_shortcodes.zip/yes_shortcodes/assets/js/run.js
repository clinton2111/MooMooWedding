!function($) {
	
	/**
	 * Loads when custom shortcode param is appended to edit form
	 */
	
	
	//initialize google map widget
    init_gmap_loc();
    
    //scroll to selected icon
    align_selected_font_icon();
    
}(window.jQuery);

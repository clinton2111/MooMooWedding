<?php
return array(
	'flaticon-couple59' => 'flaticon-couple59',
	'flaticon-event5' => 'flaticon-event5',
	'flaticon-guestbook' => 'flaticon-guestbook',
	'flaticon-invitation' => 'flaticon-invitation',
	'flaticon-little8' => 'flaticon-little8',
	'flaticon-man204' => 'flaticon-man204',
	'flaticon-man209' => 'flaticon-man209',
	'flaticon-person122' => 'flaticon-person122',
	'flaticon-person123' => 'flaticon-person123',
	'flaticon-present2' => 'flaticon-present2',
	'flaticon-quill1' => 'flaticon-quill1',
	'flaticon-recognition6' => 'flaticon-recognition6',
	'flaticon-slr2' => 'flaticon-slr2',
	'flaticon-social19' => 'flaticon-social19',
	'flaticon-vintage2' => 'flaticon-vintage2',
);
?>